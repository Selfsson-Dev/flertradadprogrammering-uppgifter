﻿namespace Assignment4_CS_GUI;

public enum BufferStatus
{
    Empty,
    Checked,
    New
}