﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace BankruptByBugs_part1
{
    public class BankAccount
    {
        public double balance;
        public Security security;
        private object lockTransaction = new object();
        public bool UseLock { get;  set; }
        public int numberOfTransactions;
    
        public BankAccount(int numberOfClients) 
        {
            security = new(numberOfClients);
        }

        public void Transaction(double amount, int clientId)
        {
            if (UseLock)
            {
                lock (lockTransaction)
                {
                    security.MakePreTransactionStamp(balance, clientId);
                    balance += amount;
                    numberOfTransactions++;
                    security.MakePostTransactionsStamp(balance, clientId);
                    security.VerifyLastTransaction(amount, clientId);
                }
            }
            else
            {
                security.MakePreTransactionStamp(balance, clientId);
                balance += amount;
                numberOfTransactions++;
                security.MakePostTransactionsStamp(balance, clientId);
                security.VerifyLastTransaction(amount, clientId);
            }
        }
    }
}